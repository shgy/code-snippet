# coding=utf8
__author__ = 'shgy'
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.http.response import HttpResponse
import hangzhou_tracks

import json

def index(request):

    return render(request, 'index.html')

def hangzhou_track(request):

    data = hangzhou_tracks.hangzhou_data

    return HttpResponse(json.dumps(data, ensure_ascii=False, indent=True),
                        content_type='application/json;charset=utf-8')