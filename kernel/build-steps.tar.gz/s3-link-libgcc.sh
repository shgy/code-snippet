cd /vita/cross-gcc-tmp/
ln -s libgcc.a lib/gcc/i686-none-linux-gnu/4.7.3/libgcc_eh.a
