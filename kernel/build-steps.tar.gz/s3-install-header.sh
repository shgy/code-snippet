cd linux-3.7.4
make ARCH=i386 INSTALL_HDR_PATH=$SYSROOT/usr/ headers_install
