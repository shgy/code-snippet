tar xvf ../glibc-2.15.tar.xz
tar xvf ../glibc-ports-2.15.tar.bz2
mv glibc-ports-2.15.tar.gz glibc-2.15/ports
