tar xvf ../source/gcc-4.7.3.tar.bz2
cd gcc-4.7.3
tar xvf ../../source/gmp-5.0.5.tar.bz2
mv gmp-5.0.5/ gmp
tar xvf ../../source/mpfr-3.1.1.tar.bz2
mv mpfr-3.1.1/ mpfr
tar xvf ../../source/mpc-1.0.1.tar.gz
mv mpc-1.0.1/ mpc
mkdir ../gcc-build 

